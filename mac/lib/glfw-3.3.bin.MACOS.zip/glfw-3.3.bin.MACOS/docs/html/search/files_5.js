var searchData=
[
  ['news_2edox',['news.dox',['../news_8dox.html',1,'']]]
];
